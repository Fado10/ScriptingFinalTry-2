using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurretControlling : MonoBehaviour
{
    [SerializeField] private Transform emitter;
    [SerializeField] private Transform player;

    [Tooltip("Inactive and Active positions for the turret")]
    [SerializeField] private Transform inactive, active;
    
    [SerializeField] private Animator anim;

    [SerializeField] private bool canSeePlayer = false;

    [SerializeField] private GameObject bulletPrefab;

    private Vector3 startPosition;
    private Quaternion startRotation;

    private Queue<Rigidbody> bulletPool = new Queue <Rigidbody>();
    
    // Start is called before the first frame update
    void Start()
    {
        anim = this.GetComponent<Animator>();
        startPosition = this.transform.position;
        startRotation = this.transform.rotation;
    }

    // Update is called once per frame
    void Update()
    {
        if(canSeePlayer) this.transform.LookAt(player);
    }

    public void Activate() {
        anim.SetTrigger("Activate");
        StartCoroutine(MoveInToPosition());
        StartCoroutine(LookForPlayer());
    }

    IEnumerator LookForPlayer() {
        while(true) {
            yield return new WaitForSeconds(0.1f);

              Ray ray = new Ray(emitter.position, player.transform.position - emitter.position);
            RaycastHit hit;
            if(Physics.Raycast(ray,out hit, 100)) {
                if (hit.transform.gameObject.CompareTag("Player")) {

                   // lets try this
                   Vector3 targetDir = player.transform.position - emitter.position;
                   float angle = Vector3.Angle(targetDir, emitter.forward);

                   if(angle < 45) {
                        Debug.Log("Found player");
                        //Start Shooting
                        FoundPlayer();
                        Debug.DrawRay(emitter.position, player.transform.position - emitter.position, Color.green, 4);
                   } else {
                        LostPlayer();
                        Debug.DrawRay(emitter.position, player.transform.position - emitter.position, Color.yellow, 4);
                   }

                } else {
                    Debug.DrawRay(emitter.position, player.transform.position - emitter.position, Color.red, 4);
                    LostPlayer();
            }   }
        }
    }

    void FoundPlayer() {
        if(canSeePlayer == false) {
            anim.SetTrigger("Fire");
            canSeePlayer = true;
        }
    }

     void LostPlayer() {
        if(canSeePlayer) {
            anim.SetTrigger("Idle");
            canSeePlayer = false;
            this.transform.position = startPosition;
            this.transform.rotation = startRotation;
        }
     }

     void Shoot() {
        Debug.Log("Bang!");
       GameObject bullet = Instantiate(bulletPrefab, emitter.position, emitter.rotation);
       Rigidbody rb;

       if(bulletPool.Count > 0) {
              Debug.Log ("Bullet Bool Active");
              rb = bulletPool.Dequeue();
              rb.gameObject.SetActive(true);
              rb.velocity = Vector3.zero;

       } else {
              rb = Instantiate(bulletPrefab, emitter.position, emitter.rotation).GetComponent<Rigidbody>();
              }

       rb.AddRelativeForce(Vector3.forward * 100, ForceMode.Impulse);
       StartCoroutine(StoreBullet(rb));
     }

     IEnumerator MoveInToPosition() {
        float t = 0;
        Transform partWithAni = this.transform.GetChild(0);
        while(t < 1) {
            partWithAni.position = Vector3.Lerp(inactive.position, active.position,t);
            t += Time.deltaTime;
            yield return new WaitForEndOfFrame();
        }
     }

     IEnumerator StoreBullet(Rigidbody bullet) {
        yield return new WaitForSeconds (0.2f);
        if (bullet.gameObject.activeSelf == true){
               bullet.gameObject.SetActive(false);
               bullet.transform.position = emitter.position;
               bullet.transform.rotation = emitter. rotation;
        }  
     }
}
