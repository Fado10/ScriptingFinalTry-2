using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SecurityCamera : MonoBehaviour
{
    [SerializeField] private float lookInterval = 0.1f;
    [Range(30,110)]
    [SerializeField] private float fieldOfVeiw = 75;
    private Transform emitter;
    private GameObject player;
    private bool canSeePlayer = false;
 
    // Start is called before the first frame update
    void Start()
    {
        emitter = this.transform.GetChild(0);
        player = GameObject.Find("FirstPersonController");
        StartCoroutine(CheckForPlayers());
    }


    IEnumerator CheckForPlayers(){
        while(true) {
            yield return new WaitForSeconds (lookInterval);

           

            
            Ray ray = new Ray(emitter.position, player.transform.position - emitter.position);
            RaycastHit hit;
            if(Physics.Raycast(ray,out hit, 100)) {
                if (hit.transform.gameObject.CompareTag("Player")) {

                   // lets try this
                   Vector3 targetDir = player.transform.position - emitter.position;
                   float angle = Vector3.Angle(targetDir, emitter.forward);

                   if(angle < fieldOfVeiw) {
                        Debug.Log("Found player");
                        // be bo ba bamb
                        StartCoroutine(CallTurrets());
                        Debug.DrawRay(emitter.position, player.transform.position - emitter.position, Color.green, 4);
                   } else {
                   canSeePlayer = false;
                   Debug.DrawRay(emitter.position, player.transform.position - emitter.position, Color.yellow, 4);
                   }

                } else {
                    canSeePlayer = false;
                    Debug.DrawRay(emitter.position, player.transform.position - emitter.position, Color.red, 4);
                }              
            }
        }   
    }

    IEnumerator CallTurrets() {
    Debug.Log("Calling");
        if(canSeePlayer == false) {
        canSeePlayer = true;
        yield return new WaitForSeconds(1);
            // shooty shooty bang bang
            if(canSeePlayer) {
                // Find all turtts
                GameObject[] turrets = GameObject.FindGameObjectsWithTag("Turret");
                foreach(GameObject turret in turrets) {
                    turret.GetComponent<TurretControlling>().Activate();
                }
            }
        }
    }
}
